Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.1");

	web_reg_find("Text=UAT - DC Health Link | Welcome to DC's Health Insurance Marketplace", 
		LAST);

	web_add_cookie("SSESSd887f51ab6d1bc995bd49426f78d3b00=joerMjUuHJ60BaSVjEFJVqWkQ-XZL9zDh_p4d_nadCA; DOMAIN=qa2.dchealthlink.com");

	web_add_cookie("has_js=1; DOMAIN=qa2.dchealthlink.com");

	web_url("qa2.dchealthlink.com:4443", 
		"URL=https://qa2.dchealthlink.com:4443/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/sites/all/modules/calendar/css/calendar_multiday.css?nu66an", ENDITEM, 
		"Url=/sites/all/modules/date/date_api/date.css?nu66an", ENDITEM, 
		"Url=/sites/all/modules/date/date_popup/themes/datepicker.1.7.css?nu66an", ENDITEM, 
		"Url=/sites/all/modules/fences/field.css?nu66an", ENDITEM, 
		"Url=/sites/all/modules/extlink/extlink.css?nu66an", ENDITEM, 
		"Url=/sites/all/modules/views/css/views.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/css/bootstrap-theme.min.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/css/bootstrap.min.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/css/bootstrap-theme.xtras.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/css/shared.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/css/home.css?nu66an", ENDITEM, 
		"Url=/sites/all/modules/ctools/css/ctools.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/img/stock/home-page-layout.jpg", "Referer=https://qa2.dchealthlink.com:4443/sites/all/themes/dchl/css/home.css?nu66an", ENDITEM, 
		"Url=/sites/all/modules/extlink/extlink.png", "Referer=https://qa2.dchealthlink.com:4443/sites/all/modules/extlink/extlink.css?nu66an", ENDITEM, 
		LAST);

	web_reg_find("Text=UAT - Individual &amp; Family | DC Health Link", 
		LAST);

	web_link("Individual & Family", 
		"Text=Individual & Family", 
		"Ordinal=1", 
		"Snapshot=t10.inf", 
		EXTRARES, 
		"Url=/sites/all/themes/dchl/css/v2_3up_landing.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/img/icon/clipboard-green.png", "Referer=https://qa2.dchealthlink.com:4443/sites/all/themes/dchl/css/v2_3up_landing.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/img/icon/progress-green-on.png", "Referer=https://qa2.dchealthlink.com:4443/sites/all/themes/dchl/css/v2_3up_landing.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/img/icon/shop-green.png", "Referer=https://qa2.dchealthlink.com:4443/sites/all/themes/dchl/css/v2_3up_landing.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/img/icon/mouse-click-green.png", "Referer=https://qa2.dchealthlink.com:4443/sites/all/themes/dchl/css/v2_3up_landing.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/img/icon/details-md-grey.png", "Referer=https://qa2.dchealthlink.com:4443/sites/all/themes/dchl/css/shared.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/img/icon/person-circle-gray.png", "Referer=https://qa2.dchealthlink.com:4443/sites/all/themes/dchl/css/shared.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/img/icon/person-gray.png", "Referer=https://qa2.dchealthlink.com:4443/sites/all/themes/dchl/css/shared.css?nu66an", ENDITEM, 
		"Url=/sites/all/themes/dchl/img/icon/tax-filings-grey.png", "Referer=https://qa2.dchealthlink.com:4443/sites/all/themes/dchl/css/shared.css?nu66an", ENDITEM, 
		LAST);

	web_reg_find("Text=DC Plan Comparison Tool 2016", 
		LAST);

	web_link("Continue", 
		"Text=Continue", 
		"Ordinal=1", 
		"Snapshot=t11.inf", 
		EXTRARES, 
		"Url=2016/assets/img/icons/info-md-blue.png", "Referer=http://staging.checkbookhealth.org/hie/dc/2016/assets/css/globalV2.css", ENDITEM, 
		"Url=2016/assets/img/icons/video-md-blue.png", "Referer=http://staging.checkbookhealth.org/hie/dc/2016/assets/css/globalV2.css", ENDITEM, 
		"Url=http://fonts.gstatic.com/s/opensans/v13/cJZKeOuBrn4kERxqtaUH3VtXRa8TVwTICgirnJhmVJw.woff2", "Referer=http://fonts.googleapis.com/css?family=Open+Sans:600,800,400,700,300", ENDITEM, 
		"Url=http://fonts.gstatic.com/s/opensans/v13/DXI1ORHCpsQm3Vp6mXoaTegdm0LZdjqr5-oayXSOefg.woff2", "Referer=http://fonts.googleapis.com/css?family=Open+Sans:600,800,400,700,300", ENDITEM, 
		"Url=http://fonts.gstatic.com/s/opensans/v13/k3k702ZOKiLJc3WVjuplzOgdm0LZdjqr5-oayXSOefg.woff2", "Referer=http://fonts.googleapis.com/css?family=Open+Sans:600,800,400,700,300", ENDITEM, 
		"Url=http://fonts.gstatic.com/s/opensans/v13/MTP_ySUJH_bn48VBG8sNSugdm0LZdjqr5-oayXSOefg.woff2", "Referer=http://fonts.googleapis.com/css?family=Open+Sans:600,800,400,700,300", ENDITEM, 
		"Url=2016/assets/img/icons/plus-md-blue.png", "Referer=http://staging.checkbookhealth.org/hie/dc/2016/assets/css/globalV2.css", ENDITEM, 
		"Url=2016/assets/img/icons/reload-md-blue.png", "Referer=http://staging.checkbookhealth.org/hie/dc/2016/assets/css/globalV2.css", ENDITEM, 
		"Url=2016/assets/img/icons/flag-lg-yellow.png", "Referer=http://staging.checkbookhealth.org/hie/dc/2016/assets/css/globalV2.css", ENDITEM, 
		LAST);

	web_reg_find("Text=DC Plan Comparison Tool 2016 - Tell us about those who will be covered under this insurance", 
		LAST);

	web_link("Continue_2", 
		"Text=Continue", 
		"Snapshot=t12.inf", 
		EXTRARES, 
		"Url=http://fonts.gstatic.com/s/opensans/v13/MTP_ySUJH_bn48VBG8sNSugdm0LZdjqr5-oayXSOefg.woff2", "Referer=http://fonts.googleapis.com/css?family=Open+Sans:600,800,400,700,300", ENDITEM, 
		LAST);

	web_add_cookie("searchVariables=%7B%22peopleCovered%22%3A%5B%7B%22id%22%3A1%2C%22age%22%3A%2225%22%2C%22healthStatus%22%3A%22%22%2C%22medicalExpense%22%3A%22%22%2C%22smoker%22%3A0%2C%22native%22%3A0%2C%22pregnant%22%3A0%7D%5D%7D; DOMAIN=staging.checkbookhealth.org");

	web_url("api.cfc", 
		"URL=http://staging.checkbookhealth.org/hie/dc/2016/api/api.cfc?age=25&county=Washington+DC&householdnumber=5&income=50000&method=calculateSubsidy&native=0&pregnant=0", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://staging.checkbookhealth.org/hie/dc/2016/search.cfm?data=eyJGT1JNVkFMVUVTIjp7fSwiVVJMVkFMVUVTIjp7InN0YXJ0IjoiIn19", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_find("Text=DC Plan Comparison Tool 2016 - Doctor Preferences", 
		LAST);

	web_url("doctors.cfm", 
		"URL=http://staging.checkbookhealth.org/hie/dc/2016/doctors.cfm?age=25&healthStatus=A&medicalExpense=&pregnant=0&native=0&findSubsidy=yes&householdNumber=5&employerCoverage=no&income=50000", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://staging.checkbookhealth.org/hie/dc/2016/search.cfm?data=eyJGT1JNVkFMVUVTIjp7fSwiVVJMVkFMVUVTIjp7InN0YXJ0IjoiIn19", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_find("Text=Welcome to DC Health Link | DC Health Link", 
		LAST);

	web_reg_find("Text=Welcome to DC Health Link | DC Health Link", 
		LAST);

	web_url("redirect.cfm", 
		"URL=http://staging.checkbookhealth.org/hie/dc/2016/redirect.cfm?to=dcHealthLink", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://staging.checkbookhealth.org/hie/dc/2016/search.cfm?data=eyJGT1JNVkFMVUVTIjp7fSwiVVJMVkFMVUVTIjp7InN0YXJ0IjoiIn19", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://app.dchealthlink.com/oaam_server/dhs/ui/dcas-ui-wrapper-img/pagebg.png", "Referer=https://app.dchealthlink.com/oaam_server/dhs/ui/dcas-ui-wrapper-css/main.css", ENDITEM, 
		"Url=https://app.dchealthlink.com/oaam_server/dhs/ui/dcas-ui-wrapper-img/bodybg.png", "Referer=https://app.dchealthlink.com/oaam_server/dhs/ui/dcas-ui-wrapper-css/main.css", ENDITEM, 
		"Url=https://app.dchealthlink.com/oaam_server/dhs/ui/dcas-ui-wrapper-img/logo-bg.jpg", "Referer=https://app.dchealthlink.com/oaam_server/dhs/ui/dcas-ui-wrapper-css/main.css", ENDITEM, 
		"Url=https://app.dchealthlink.com/oaam_server/dhs/ui/dcas-ui-wrapper-img/ico-warning.png", "Referer=https://app.dchealthlink.com/oaam_server/dhs/ui/dcas-ui-wrapper-css/main.css", ENDITEM, 
		"Url=https://app.dchealthlink.com/oaam_server/dhs/ui/dcas-ui-wrapper-css/fonts/fontawesome-webfont.woff?v=3.2.1", "Referer=https://app.dchealthlink.com/oaam_server/dhs/ui/dcas-ui-wrapper-css/font-awesome.min.css", ENDITEM, 
		LAST);

	return 0;
}